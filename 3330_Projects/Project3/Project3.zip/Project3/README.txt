Name: Cesar Cantu-Perez
ID# 1001463763
Date: 4/30/2022

I am using a Windows 10 computer for my OS.
To run this program, I used IntelliJ as a Java IDE. In intelliJ, I was able to connect with mySQL using java imports, connections, and statements.
Also, IntelliJ let me add the mysql driver into the class path so I cound connect the program to mySQL which was something I could not do in the command line.
When I ran the program through the command line, using "javac Project3JDBC.java" and "java Project3JDBC" I got the "no suitable driver found for jdbc:mysql" error.
However when running through IntelliJ, the project works perfectly.
For the mySQL database the url used in the code is "jdbc:mysql://localhost:3306/newschema" where the schems is called "newschema".
The username is "root" and the password is: "Carrillo2!"
I have also included the create and insert statements in "Lab1.sql" to be able to build the database.